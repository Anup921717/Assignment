import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public class BankStatementBatchProcessor {
 
     //FIX: AtomicInteger makes the counter increment atomic when 10  
     //threads update it concurrently. processedCount++ is a read-modify-write- 
     //Operation, so concurrent increments can be lost.
       private final AtomicInteger processedCount = new AtomicInteger(0);
 
    public void process(List<StatementRecord> records) {
        ExecutorService executor = Executors.newFixedThreadPool(10);
 
        for (StatementRecord record : records) {
            executor.submit(() -> {
                processRecord(record);

                // FIX: Atomic increment prevents lost counter updates.
                processedCount.incrementAndGet();          });
        }
        executor.shutdown();
        executor.awaitTermination(5, TimeUnit.MINUTES);
    }
 
    public int getProcessedCount() {
       // FIX: AtomicInteger must be converted to int using get().
        return processedCount.get();
    }
}
