# Task 2 Analysis

## 1. What is the exact cause of ConcurrentModificationException in Java?
ConcurrentModificationException occurs when an ArrayList` is structurally modified while it is being iterated.
For example, removing an element directly from the list while using an iterator or enhanced for loop can cause this exception.
It does not always mean multiple threads are involved. A single thread can also cause it by modifying the list during iteration.

## 2. What code pattern at line 142 most likely triggered this error?
The most likely code pattern is removing an element from the list while iterating over it:

for (Transaction transaction : transactions) {
    if (someCondition(transaction)) {
        transactions.remove(transaction);
    }
}

##3. Provide the minimal code change that resolves this safely.
If the existing code uses an explicit Iterator, replace the direct list removal:
transactions.remove(transaction);
with:
iterator.remove();
Iterator<Transaction> iterator = transactions.iterator();
while (iterator.hasNext()) {
    Transaction transaction = iterator.next();
   if (someCondition(transaction)) {
     //FIX: Remove through the iterator instead of directly modifying the ArrayList while it is being iterated.
        iterator.remove();
    }
}
iterator.remove() is safe because the removal is performed through the iterator itself.