
// JUnit test that reproduces the bug and asserts the fix for Task1
import static org.junit.jupiter.api.Assertions.assertEquals;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;

class Task1Test {

    @Test
    void shouldReturnOnlyOverdueLoansWithPositiveBalance() {

        Date yesterday = new Date(System.currentTimeMillis() - 24 * 60 * 60 * 1000);

        // Overdue + positive balance -> should be included
        LoanAccount overdueLoan =
                new LoanAccount("L001", yesterday, 5000);

        // Overdue + zero balance -> should NOT be included
        LoanAccount zeroBalanceLoan =
                new LoanAccount("L002", yesterday, 0);

        // Null dueDate -> should NOT throw exception
        LoanAccount restructuredLoan =
                new LoanAccount("L003", null, 3000);

        List<LoanAccount> accounts = Arrays.asList(
                overdueLoan,
                zeroBalanceLoan,
                restructuredLoan
        );

        LoanAccountService service = new LoanAccountService();

        List<LoanAccount> result =
                service.getOverdueLoans(accounts);

        // FIX: Only the overdue loan with positive balance should be returned.
        assertEquals(1, result.size());

        // FIX: Verify that the correct account was returned.
        assertEquals("L001", result.get(0).getAccountId());
    }
}