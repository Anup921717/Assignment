import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public List<LoanAccount> getOverdueLoans(List<LoanAccount> accounts) {

   // FIX: Initialize the result list before adding accounts.
    List<LoanAccount> result = new ArrayList<>();
 
    for (LoanAccount account : accounts) {

            // FIX: dueDate can be null for restructured accounts,
       //so check it before calling before().
        if (account.getDueDate()!=null && account.getDueDate().before(new Date())) {

        // FIX: Only accounts with a positive outstanding balance are overdue.
         // Zero outstanding balance accounts must not be included.                                          
            if (account.getOutstandingBalance() > 0) {
                result.add(account);
            }
        }
    }
    return result;
}
 
// LoanAccount fields:
// Date dueDate          — may be null for restructured accounts
// double outstandingBalance
// String accountId      — always non-null
