import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DocumentValidator {

private static final Logger logger =
            LoggerFactory.getLogger(DocumentValidator.class);

public ValidationResult validate(Document doc) {
    try {
        if (doc == null) {
            throw new RuntimeException("Document is null");
        }
        String content = doc.extractContent();
        if (content.isEmpty()) {
            throw new RuntimeException("Empty content");
        }
        return runValidationRules(content);
 
    } catch (Exception e) {

        // FIX: Do not use printStackTrace() for expected validation errors. 
        // Log only the validation message to avoid flooding the logs.         
          logger.warn("Validation failed: {}", e.getMessage());

        // FIX: Do not return null because the caller may call methods on 
       // the result and get NullPointerException. 
        return new ValidationResult(false, e.getMessage());}
}
 
      public void validateBatch(List<Document> docs) {
      for (Document doc : docs) {
        try {
            ValidationResult r = validate(doc);
            // FIX: Check for null before calling isValid().          
             if(r!= null && r.isValid()) { 
                saveResult(r);            }
        } catch (Exception e) {
           // FIX: Do not silently swallow unexpected exceptions. 
           // Log the unexpected failure with its stack trace.       
           logger.error("Unexpected error while validating document", e);

        }
    }
}
}